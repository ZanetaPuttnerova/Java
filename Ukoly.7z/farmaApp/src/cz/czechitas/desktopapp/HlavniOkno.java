package cz.czechitas.desktopapp;

import java.awt.*;
import java.awt.event.*;
import java.text.*;
import javax.swing.*;
import net.miginfocom.swing.*;

public class HlavniOkno extends JFrame {

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner non-commercial license
    JLabel labEvidence;
    JLabel labKralici;
    JLabel labHusy;
    JLabel labPocetKSamic;
    JTextField editPocetKSamic;
    JLabel labPocetHSamic;
    JTextField editPocetHSamic;
    JLabel labPocetKSamcu;
    JTextField editPocetKSamcu;
    JLabel labPocetHSamcu;
    JTextField editPocetHSamcu;
    JButton btnVypocti;
    JLabel labVelikostChovu;
    JLabel labVelikostChovuVeta;
    JLabel labPotrebaKrmiva;
    JLabel labPopisek;
    JLabel labMrkev;
    JTextField editMrkev;
    JLabel labRadkyMrkve;
    JTextField editRadkyMrkve;
    JLabel labPsenice;
    JTextField editPsenice;
    JLabel labRadkyPsenice;
    JTextField editRadkyPsenice;
    JLabel labVetaMrkev;
    JLabel labVetaPsenice;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
    JPanel contentPane;
    MigLayout migLayoutManager;


    public HlavniOkno() {
        initComponents();
        // 91,5 Kg mrkve na králíka  , na řádek 5 Kg mrkve  tj. 18,3 řádků na králíka
    //45,75 Kg pšenice na husu   , na řádek 2 Kg pšenice tj. 22,9 řádků na husu
    }

    private void btnVypoctiPotrebuPlodin(ActionEvent e) {
        String pocetKSamic = editPocetKSamic.getText();
        String pocetKSamcu = editPocetKSamcu.getText();
        Double kralikM = 0.0;
        Double kralikZ = 0.0;
        Double velikostChovuK = 0.0;
        String pocetHSamic = editPocetHSamic.getText();
        String pocetHSamcu = editPocetHSamcu.getText();
        Double husaM = 0.0;
        Double husaZ = 0.0;
        Double velikostChovuH = 0.0;

        String mrkev;
        String psenice;
        Double kralici = 0.0;
        Double husy = 0.0;
        if (pocetKSamic.length() > 0) {
            kralikZ = prevedStringNaInt(pocetKSamic);
        }
        if (pocetKSamcu.length() > 0) {
            kralikM = prevedStringNaInt(pocetKSamcu);
        }

        if (pocetHSamic.length() > 0) {
            husaZ = prevedStringNaInt(pocetHSamic);
        }
        if (pocetHSamcu.length() > 0) {
            husy = prevedStringNaInt(pocetHSamcu);
        }

        if (kralikZ > 0) {
            velikostChovuK = ((kralikZ * 40) + kralikZ + kralikM);
        }

        if (husaZ > 0) {
            velikostChovuH = ((husaZ * 15) + husaZ + husaM);
        }

        Double velikostChovu = velikostChovuH + velikostChovuK;
        velikostChovu.toString();
        labVelikostChovuVeta.setText("Celkem" + velikostChovuK + " králíků a " + velikostChovuH + " hus, tj." + velikostChovu + "zvířat.");


        Double potrebaMrkve = (velikostChovuK * 91.5);
        Double potrebaPsenice = (velikostChovuH * 45.75);

        mrkev = potrebaMrkve.toString();
        mrkev = String.format("%.2f", potrebaMrkve);
        editMrkev.setText(mrkev);

        psenice = potrebaPsenice.toString();
        psenice = String.format("%.2f", potrebaPsenice);
        editPsenice.setText(psenice);

        Double radkyMrkve= (potrebaMrkve / 5);
        String komentarMrkve = radkyMrkve.toString();
        editRadkyMrkve.setText(komentarMrkve);

        Double radkyPsenice= (potrebaPsenice / 2);
        String komentarPsenice = radkyPsenice.toString();
        editRadkyPsenice.setText(komentarPsenice);

        labVetaMrkev.setText("Pro " + velikostChovuK + " králíků je potřeba " + mrkev + " Kg mrkve, tj. " + komentarMrkve + " řádků." );
        labVetaPsenice.setText("Pro " + velikostChovuH + " hus je potřeba " + psenice + " Kg pšenice, tj. " + komentarPsenice + " řádků." );
        pack();
    }

    private double prevedStringNaInt(String text){
        NumberFormat reformat = NumberFormat.getInstance();
        ParsePosition pozice = new ParsePosition(0);
        Number cislo = reformat.parse(text, pozice);
        return cislo.doubleValue();
    }

    private boolean jeCislo(String text) {
        double cislo = prevedStringNaInt(text);
        return !Double.isNaN(cislo);
    }

    // Jak zařídit, aby se po zmáčknutí tlačítka "Vypočti", okno roztáhlo na potřebnou šířku?


    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner non-commercial license
        labEvidence = new JLabel();
        labKralici = new JLabel();
        labHusy = new JLabel();
        labPocetKSamic = new JLabel();
        editPocetKSamic = new JTextField();
        labPocetHSamic = new JLabel();
        editPocetHSamic = new JTextField();
        labPocetKSamcu = new JLabel();
        editPocetKSamcu = new JTextField();
        labPocetHSamcu = new JLabel();
        editPocetHSamcu = new JTextField();
        btnVypocti = new JButton();
        labVelikostChovu = new JLabel();
        labVelikostChovuVeta = new JLabel();
        labPotrebaKrmiva = new JLabel();
        labPopisek = new JLabel();
        labMrkev = new JLabel();
        editMrkev = new JTextField();
        labRadkyMrkve = new JLabel();
        editRadkyMrkve = new JTextField();
        labPsenice = new JLabel();
        editPsenice = new JTextField();
        labRadkyPsenice = new JLabel();
        editRadkyPsenice = new JTextField();
        labVetaMrkev = new JLabel();
        labVetaPsenice = new JLabel();

        //======== this ========
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("farmarka");
        setBackground(new Color(255, 204, 255));
        setMinimumSize(new Dimension(35, 40));
        Container contentPane = getContentPane();
        contentPane.setLayout(new MigLayout(
            "insets rel,hidemode 3",
            // columns
            "[20,fill]" +
            "[grow,fill]" +
            "[grow,fill]" +
            "[29,grow,fill]" +
            "[36,grow,fill]" +
            "[grow,fill]" +
            "[grow,fill]" +
            "[grow,fill]" +
            "[grow,fill]" +
            "[42,grow,fill]" +
            "[grow,fill]",
            // rows
            "[]" +
            "[grow,fill]" +
            "[grow,fill]" +
            "[grow,fill]" +
            "[]" +
            "[grow,fill]" +
            "[]" +
            "[grow,fill]" +
            "[15]" +
            "[grow,fill]" +
            "[]" +
            "[]" +
            "[]0" +
            "[]0" +
            "[]0" +
            "[0]" +
            "[grow,fill]" +
            "[]" +
            "[grow,fill]" +
            "[]" +
            "[fill]" +
            "[18,grow,fill]" +
            "[]" +
            "[grow]" +
            "[]" +
            "[]" +
            "[]"));
        this.contentPane = (JPanel) this.getContentPane();
        this.contentPane.setBackground(this.getBackground());
        LayoutManager layout = this.contentPane.getLayout();
        if (layout instanceof MigLayout) {
            this.migLayoutManager = (MigLayout) layout;
        }

        //---- labEvidence ----
        labEvidence.setText("Evidence zv\u00ed\u0159at a pl\u00e1n pot\u0159eby plodin na zimu");
        labEvidence.setFont(labEvidence.getFont().deriveFont(labEvidence.getFont().getStyle() | Font.BOLD));
        contentPane.add(labEvidence, "cell 1 1 10 1,alignx center,growx 0");

        //---- labKralici ----
        labKralici.setText("Kr\u00e1l\u00edci");
        contentPane.add(labKralici, "cell 3 2");

        //---- labHusy ----
        labHusy.setText("Husy");
        contentPane.add(labHusy, "cell 7 2");

        //---- labPocetKSamic ----
        labPocetKSamic.setText("Po\u010det samic");
        contentPane.add(labPocetKSamic, "cell 1 3 3 1");

        //---- editPocetKSamic ----
        editPocetKSamic.setMinimumSize(new Dimension(15, 25));
        contentPane.add(editPocetKSamic, "cell 4 3");

        //---- labPocetHSamic ----
        labPocetHSamic.setText("Po\u010det samic");
        contentPane.add(labPocetHSamic, "cell 6 3 3 1");

        //---- editPocetHSamic ----
        editPocetHSamic.setMinimumSize(new Dimension(15, 25));
        contentPane.add(editPocetHSamic, "cell 9 3");

        //---- labPocetKSamcu ----
        labPocetKSamcu.setText("Po\u010det samc\u016f");
        contentPane.add(labPocetKSamcu, "cell 1 5 3 1");
        contentPane.add(editPocetKSamcu, "cell 4 5");

        //---- labPocetHSamcu ----
        labPocetHSamcu.setText("Po\u010det samc\u016f");
        contentPane.add(labPocetHSamcu, "cell 6 5 3 1");
        contentPane.add(editPocetHSamcu, "cell 9 5");

        //---- btnVypocti ----
        btnVypocti.setText("Vypo\u010dti pot\u0159ebu plodin");
        btnVypocti.setBackground(new Color(255, 255, 204));
        btnVypocti.setActionCommand("Vypo\u010dti");
        btnVypocti.addActionListener(e -> btnVypoctiPotrebuPlodin(e));
        contentPane.add(btnVypocti, "cell 1 7 10 1");

        //---- labVelikostChovu ----
        labVelikostChovu.setText("Velikost chovu p\u0159ed zimou:");
        labVelikostChovu.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 10));
        contentPane.add(labVelikostChovu, "cell 1 9 8 1");
        contentPane.add(labVelikostChovuVeta, "cell 1 13 5 1");

        //---- labPotrebaKrmiva ----
        labPotrebaKrmiva.setText("Pot\u0159eba krmiva");
        labPotrebaKrmiva.setForeground(Color.red);
        labPotrebaKrmiva.setFont(new Font("Segoe UI", Font.BOLD, 12));
        contentPane.add(labPotrebaKrmiva, "cell 1 16 10 1,alignx center,growx 0");

        //---- labPopisek ----
        labPopisek.setText("P\u0159ed zimou je pot\u0159eba vyp\u011bstovat:");
        labPopisek.setFont(new Font("Segoe UI", Font.ITALIC, 10));
        labPopisek.setForeground(Color.magenta);
        contentPane.add(labPopisek, "cell 1 18 9 1");

        //---- labMrkev ----
        labMrkev.setText("Mrkev Kg");
        contentPane.add(labMrkev, "cell 1 20 3 1");

        //---- editMrkev ----
        editMrkev.setMinimumSize(new Dimension(30, 25));
        contentPane.add(editMrkev, "cell 4 20");

        //---- labRadkyMrkve ----
        labRadkyMrkve.setText("\u0158\u00e1dky mrkve");
        contentPane.add(labRadkyMrkve, "cell 6 20 3 1");

        //---- editRadkyMrkve ----
        editRadkyMrkve.setMinimumSize(new Dimension(30, 25));
        contentPane.add(editRadkyMrkve, "cell 9 20");

        //---- labPsenice ----
        labPsenice.setText("P\u0161enice Kg");
        contentPane.add(labPsenice, "cell 1 21 3 1");

        //---- editPsenice ----
        editPsenice.setMinimumSize(new Dimension(30, 25));
        contentPane.add(editPsenice, "cell 4 21");

        //---- labRadkyPsenice ----
        labRadkyPsenice.setText("\u0158\u00e1dky p\u0161enice");
        contentPane.add(labRadkyPsenice, "cell 6 21 3 1");

        //---- editRadkyPsenice ----
        editRadkyPsenice.setMinimumSize(new Dimension(30, 25));
        contentPane.add(editRadkyPsenice, "cell 9 21");

        //---- labVetaMrkev ----
        labVetaMrkev.setFont(new Font("Segoe UI", Font.ITALIC, 10));
        contentPane.add(labVetaMrkev, "cell 1 23 10 1");

        //---- labVetaPsenice ----
        labVetaPsenice.setFont(new Font("Segoe UI", Font.ITALIC, 10));
        contentPane.add(labVetaPsenice, "cell 1 25 10 1");
        pack();
        setLocationRelativeTo(null);
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }
}
