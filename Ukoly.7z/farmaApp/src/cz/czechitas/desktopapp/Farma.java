package cz.czechitas.desktopapp;

/*public class Farma {

    private Kralici kralici;
    private Husy husy;

    public int getPocetHlav() {
        return kralici.getPocetHlav() + husy.getPocetHlav();
    }

    public int getPocetNohou() {
        return kralici.getPocetNohou() + husy.getPocetNohou();
    }

    public void prepocitej (int pocetKraliku, int pocetHus) {
        husy = new Husy(pocetHus);
        husy.getPocetHlav();
    }

}
 */