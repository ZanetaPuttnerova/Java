package cz.czechitas.knihy;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.util.List;
import javax.swing.*;
import javax.swing.event.*;
import net.miginfocom.swing.*;

public class HlavniOkno extends JFrame {

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner non-commercial license
    JMenuBar menuBar1;
    JMenu menuSoubor;
    JMenuItem menuOtevritSoubor;
    JMenuItem menuUlozitSoubor;
    JMenu menuZobrazit;
    JCheckBoxMenuItem checkBoxPouzeOblibene;
    JMenuItem menuItem1;
    JMenu menuNastroje;
    JMenuItem menuItem2;
    JMenuItem menuIFiltr;
    JLabel labTitulek;
    JButton btnNahodnaKniha;
    JButton btnNahodnaOdAutora;
    JCheckBox checkBoxOblibena;
    JLabel oknoProObrazek;
    JLabel labAutor;
    JLabel labAutorEdit;
    JLabel labHodnotit;
    JLabel labKniha;
    JLabel labKnihaEdit;
    JSpinner spinnHodnoceni;
    JButton btnVyhledat;
    JTextField txtVyhledat;
    JLabel labRokStranaJazyk;
    JLabel labfPocetKnih;
    JLabel labPocetKnihEdit;
    JLabel labDostupneJazyky;
    JLabel labDostupneJazykyEdit;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
    JPanel contentPane;
    MigLayout migLayoutManager;

    Kniha aktualniKniha;
    Kniha knihaOdAutora;
    Kniha oblibenaKniha;
    ZdrojDat zdrojDat;
    KnihovniSluzba knihovniSluzba;
    Pomocnik pomocnik;

    public HlavniOkno() {
        initComponents();

        File souborDat = new File("knihy.txt");

        //zdrojDat = new SouborovyZdrojDat(souborDat) ;

         nastavKnihovniSluzbu(new SouborovyZdrojDat(souborDat));

    }

    private void pocetKnih(){
        int pocet = knihovniSluzba.getPocetKnih();
        labPocetKnihEdit.setText(String.valueOf(pocet));
    }

    private void stisknutiBtnNahodnaKniha(ActionEvent e) {
        if (checkBoxPouzeOblibene.isSelected()) {
            aktualniKniha = knihovniSluzba.getNahodnaOblibenaKniha();
        } else {
            aktualniKniha = knihovniSluzba.getNahodnaKniha();

        }
        vypisInfo();
    }


    private void stisknutiBtnNahodnaKnihaOdAutora(ActionEvent e) {
        knihaOdAutora = knihovniSluzba.getKnihyOdAutora(aktualniKniha.getAutor());
        vypisInfo();
}

    private void checkBoxPouzeOblibeneKnihyVyber(ActionEvent e) {
        if (checkBoxPouzeOblibene.isSelected()) {
            aktualniKniha = knihovniSluzba.getNahodnaOblibenaKniha();
        } else {
            aktualniKniha = knihovniSluzba.getNahodnaKniha();

        }
        vypisInfo();
    }

private void menuOtevritSoubor(ActionEvent e) {
    JFileChooser vyberovyDialog = new JFileChooser();
    int vysledek = vyberovyDialog.showOpenDialog(this);
    if (vysledek == JFileChooser.APPROVE_OPTION){
        File soubor = vyberovyDialog.getSelectedFile();
        nastavKnihovniSluzbu(new SouborovyZdrojDat(soubor));
    }
}

private void nastavKnihovniSluzbu(ZdrojDat zdroj) {
        zdrojDat = zdroj;
        knihovniSluzba = new KnihovniSluzba(zdroj);   //proměnná (int, string, ale i datum -
        pomocnik = new Pomocnik();
        pocetKnih();
        pocetJazyku();
    if (knihovniSluzba.getPocetKnih() > 0) {
        aktualniKniha = knihovniSluzba.getKniha(0);
    }
}

private void pocetJazyku() {
    List<String> jazyky = new ArrayList<String>();
    for (Kniha kniha: zdrojDat.getKnihy()){
        boolean nalezeno = false;
        for (String jazyk: jazyky){
            if (jazyk.compareTo(kniha.getJazyk())==0) {
              nalezeno = true;
            }
        }
        if (nalezeno == false){
            jazyky.add(kniha.getJazyk());
        }
    }
    int pocet = jazyky.size();
    labDostupneJazykyEdit.setText(String.valueOf(pocet));
}

private void aktualniObrazek(String obrazek){
        ImageIcon icon = new ImageIcon(obrazek);
     oknoProObrazek.setIcon(icon);
}

private void checkBoxOblibena(ActionEvent e) {
  aktualniKniha.setOblibeny(checkBoxOblibena.isSelected());
}
    /* if (checkBoxOblibena.isSelected()){
            aktualniKniha.setOblibeny(true);
        } else {
            aktualniKniha.setOblibeny(false);
        }
     */

    
private void setCheckBoxPouzeOblibene(ActionEvent e){
    aktualniKniha = knihovniSluzba.getNahodnaKniha();
   vypisInfo();
    }



private void spinnHodnoceniVyber(ChangeEvent e) {
    aktualniKniha.setHodnoceni((Integer)spinnHodnoceni.getValue());
}
    private void vypisInfo(){
    labKnihaEdit.setText(aktualniKniha.getNazev());
    labAutorEdit.setText(aktualniKniha.getAutor());
    labRokStranaJazyk.setText("Kniha byla vydaná v roce " + aktualniKniha.getRokVydani() + ", v jazyce " + aktualniKniha.getJazyk() + " , počet stran " + aktualniKniha.getPocetStran() +".");
    spinnHodnoceni.setValue(aktualniKniha.getHodnoceni());
    checkBoxOblibena.setSelected(aktualniKniha.isOblibeny());
    oknoProObrazek.setIcon(pomocnik.nactiIkonku(aktualniKniha.getObrazek()));
}

private void menuUlozitSoubor(ActionEvent e) {
    JFileChooser dialogUkladani = new JFileChooser();
    int vysledek = dialogUkladani.showOpenDialog(this);
    if (vysledek == JFileChooser.APPROVE_OPTION){
        File soubor = dialogUkladani.getSelectedFile();
        knihovniSluzba.ulozKnihyDoSouboru(soubor);
    }
}

private void btnVyhledat(ActionEvent e) {
    aktualniKniha = knihovniSluzba.najdi(txtVyhledat.getText());
    vypisInfo();
}





    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner non-commercial license
        menuBar1 = new JMenuBar();
        menuSoubor = new JMenu();
        menuOtevritSoubor = new JMenuItem();
        menuUlozitSoubor = new JMenuItem();
        menuZobrazit = new JMenu();
        checkBoxPouzeOblibene = new JCheckBoxMenuItem();
        menuItem1 = new JMenuItem();
        menuNastroje = new JMenu();
        menuItem2 = new JMenuItem();
        menuIFiltr = new JMenuItem();
        labTitulek = new JLabel();
        btnNahodnaKniha = new JButton();
        btnNahodnaOdAutora = new JButton();
        checkBoxOblibena = new JCheckBox();
        oknoProObrazek = new JLabel();
        labAutor = new JLabel();
        labAutorEdit = new JLabel();
        labHodnotit = new JLabel();
        labKniha = new JLabel();
        labKnihaEdit = new JLabel();
        spinnHodnoceni = new JSpinner();
        btnVyhledat = new JButton();
        txtVyhledat = new JTextField();
        labRokStranaJazyk = new JLabel();
        labfPocetKnih = new JLabel();
        labPocetKnihEdit = new JLabel();
        labDostupneJazyky = new JLabel();
        labDostupneJazykyEdit = new JLabel();

        //======== this ========
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("knihy");
        setBackground(new Color(204, 204, 0));
        Container contentPane = getContentPane();
        contentPane.setLayout(new MigLayout(
            "insets rel,hidemode 3",
            // columns
            "[fill]" +
            "[fill]" +
            "[fill]" +
            "[fill]" +
            "[fill]" +
            "[]" +
            "[fill]rel" +
            "[fill]" +
            "[fill]" +
            "[fill]" +
            "[fill]" +
            "[fill]rel" +
            "[fill]rel" +
            "[26,fill]rel" +
            "[28,fill]" +
            "[46,fill]rel" +
            "[35,fill]" +
            "[51,fill]" +
            "[fill]" +
            "[fill]" +
            "[fill]" +
            "[fill]" +
            "[fill]" +
            "[61,fill]" +
            "[fill]",
            // rows
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[grow]" +
            "[]" +
            "[]"));
        this.contentPane = (JPanel) this.getContentPane();
        this.contentPane.setBackground(this.getBackground());
        LayoutManager layout = this.contentPane.getLayout();
        if (layout instanceof MigLayout) {
            this.migLayoutManager = (MigLayout) layout;
        }

        //======== menuBar1 ========
        {

            //======== menuSoubor ========
            {
                menuSoubor.setText("Soubor");

                //---- menuOtevritSoubor ----
                menuOtevritSoubor.setText("Otev\u0159\u00edt");
                menuOtevritSoubor.addActionListener(e -> menuOtevritSoubor(e));
                menuSoubor.add(menuOtevritSoubor);

                //---- menuUlozitSoubor ----
                menuUlozitSoubor.setText("Ulo\u017eit");
                menuUlozitSoubor.addActionListener(e -> menuUlozitSoubor(e));
                menuSoubor.add(menuUlozitSoubor);
            }
            menuBar1.add(menuSoubor);

            //======== menuZobrazit ========
            {
                menuZobrazit.setText("Zobrazit");

                //---- checkBoxPouzeOblibene ----
                checkBoxPouzeOblibene.setText("Pouze obl\u00edben\u00e9");
                checkBoxPouzeOblibene.addActionListener(e -> checkBoxPouzeOblibeneKnihyVyber(e));
                menuZobrazit.add(checkBoxPouzeOblibene);
                menuZobrazit.add(menuItem1);
            }
            menuBar1.add(menuZobrazit);

            //======== menuNastroje ========
            {
                menuNastroje.setText("N\u00e1stroje");

                //---- menuItem2 ----
                menuItem2.setText("Vyhledat");
                menuNastroje.add(menuItem2);

                //---- menuIFiltr ----
                menuIFiltr.setText("Filtr");
                menuNastroje.add(menuIFiltr);
            }
            menuBar1.add(menuNastroje);
        }
        setJMenuBar(menuBar1);

        //---- labTitulek ----
        labTitulek.setText("Katalog knih");
        labTitulek.setFont(new Font("Segoe UI", Font.BOLD, 26));
        contentPane.add(labTitulek, "cell 2 1 16 1,alignx center,growx 0");

        //---- btnNahodnaKniha ----
        btnNahodnaKniha.setText("N\u00e1hodn\u00e1 kniha");
        btnNahodnaKniha.setBackground(new Color(0, 204, 153));
        btnNahodnaKniha.addActionListener(e -> stisknutiBtnNahodnaKniha(e));
        contentPane.add(btnNahodnaKniha, "cell 1 2 6 1");

        //---- btnNahodnaOdAutora ----
        btnNahodnaOdAutora.setText("N\u00e1hodn\u00e1 od autora");
        btnNahodnaOdAutora.setPreferredSize(new Dimension(133, 32));
        btnNahodnaOdAutora.setMaximumSize(new Dimension(133, 32));
        btnNahodnaOdAutora.setMinimumSize(new Dimension(133, 32));
        btnNahodnaOdAutora.setBackground(new Color(0, 204, 153));
        btnNahodnaOdAutora.addActionListener(e -> stisknutiBtnNahodnaKnihaOdAutora(e));
        contentPane.add(btnNahodnaOdAutora, "cell 7 2 5 1");

        //---- checkBoxOblibena ----
        checkBoxOblibena.setText("Obl\u00edben\u00e1");
        checkBoxOblibena.setMaximumSize(new Dimension(90, 24));
        checkBoxOblibena.setBackground(new Color(0, 204, 153));
        checkBoxOblibena.addActionListener(e -> checkBoxOblibena(e));
        contentPane.add(checkBoxOblibena, "cell 12 2 3 1,alignx left,growx 0");

        //---- oknoProObrazek ----
        oknoProObrazek.setIcon(new ImageIcon(getClass().getResource("/cz/czechitas/knihy/images/absalom-absalom.jpg")));
        oknoProObrazek.setMaximumSize(new Dimension(400, 500));
        oknoProObrazek.setMinimumSize(new Dimension(60, 80));
        oknoProObrazek.setPreferredSize(new Dimension(400, 500));
        contentPane.add(oknoProObrazek, "cell 15 2 9 11,align left top,grow 0 0");

        //---- labAutor ----
        labAutor.setText("Autor");
        labAutor.setFont(labAutor.getFont().deriveFont(labAutor.getFont().getStyle() | Font.BOLD));
        contentPane.add(labAutor, "cell 1 3");
        contentPane.add(labAutorEdit, "cell 2 3 11 1");

        //---- labHodnotit ----
        labHodnotit.setText("Hodnotit");
        labHodnotit.setBackground(new Color(0, 204, 153));
        contentPane.add(labHodnotit, "cell 13 4 2 1");

        //---- labKniha ----
        labKniha.setText("Kniha");
        labKniha.setFont(labKniha.getFont().deriveFont(labKniha.getFont().getStyle() | Font.BOLD));
        contentPane.add(labKniha, "cell 1 5");
        contentPane.add(labKnihaEdit, "cell 2 5 11 1");

        //---- spinnHodnoceni ----
        spinnHodnoceni.setModel(new SpinnerNumberModel(1, 1, 5, 1));
        spinnHodnoceni.setBackground(new Color(0, 204, 153));
        spinnHodnoceni.addChangeListener(e -> spinnHodnoceniVyber(e));
        contentPane.add(spinnHodnoceni, "cell 13 5 2 1");

        //---- btnVyhledat ----
        btnVyhledat.setText("Vyhledat podle n\u00e1zvu knihy");
        btnVyhledat.addActionListener(e -> btnVyhledat(e));
        contentPane.add(btnVyhledat, "cell 1 7 6 1");
        contentPane.add(txtVyhledat, "cell 7 7 8 1");

        //---- labRokStranaJazyk ----
        labRokStranaJazyk.setText("Kniha byla vyd\u00e1na v roce d, v jazyc\u00edch x,y , po\u010det stran: .");
        contentPane.add(labRokStranaJazyk, "cell 1 9 17 1");

        //---- labfPocetKnih ----
        labfPocetKnih.setText("Po\u010det knih celkem:");
        contentPane.add(labfPocetKnih, "cell 1 10 4 1");
        contentPane.add(labPocetKnihEdit, "cell 5 10 2 1,alignx left,growx 0");

        //---- labDostupneJazyky ----
        labDostupneJazyky.setText("Dostupn\u00e9 jazyky:");
        contentPane.add(labDostupneJazyky, "cell 9 10 4 1,alignx trailing,growx 0");
        contentPane.add(labDostupneJazykyEdit, "cell 13 10,alignx left,growx 0");
        pack();
        setLocationRelativeTo(null);
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }
}

/* obecný objekt =  počítač, typ je instance, konkrétní, dvě instnce třídy Color, new Date je objekt
Kůň je složený typ, takže s velkým K
objekt je konkrétní se jménem a tomu už můžu dat ukol
Color je tyyp (složený)
foreground (je proměnná držák na objekty, člověk je proměnná, pc objekt), má v sobě spoustu dalších charakeristik))
 třída je vzdy jednotné číslo, na více objektů se používá seznam
 REPL groovy
 složené typy jsou třídy,
 objekt instance promenna
 new Random -výroba nového objektu = instance( patří třídě Random), konkrétní náhodnýRandom je proměnná)
 Color nahodnaBarva = proměnná
 new Color - výroba objektu

 typ kůň, objekt tadyten, proměnná můjTonda - držák
 izolace = new Color(cervena, zelena, modra)

 btn getValue
 */