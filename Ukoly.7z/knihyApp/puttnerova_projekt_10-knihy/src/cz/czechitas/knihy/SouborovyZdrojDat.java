package cz.czechitas.knihy;

import java.io.*;
import java.util.*;
import javax.swing.*;
import javax.xml.bind.*;
import  cz.czechitas.knihy.*;
import javafx.scene.control.*;

public class SouborovyZdrojDat implements ZdrojDat {

    private List<Kniha> knihy;
    private File soubor;

    public SouborovyZdrojDat(File soubor) {
        knihy = nactiKnihyZeSouboru(soubor);
        this.soubor = soubor;
    }

    public Kniha getKniha(int i){
        return knihy.get(i);
    }

    private List<Kniha> nactiKnihyZeSouboru(File zdrojovySoubor) {
        List<Kniha> knihy = new ArrayList<>();
        Pomocnik honzik = new Pomocnik();

        List<String> radky = honzik.nactiRadkySouboru(zdrojovySoubor);

        for (int i =0; i<radky.size(); i = i + 1){
            List <String> radek = honzik.rozdelRadek(radky.get(i));
            String autor = radek.get(1);
            String nazev = radek.get(0);
            String jazyk = radek.get(4);
            String obrazek = "/cz/czechitas/knihy/" + radek.get(5);
            int rokVydani = Integer.parseInt(radek.get(2));
            int pocetStran = Integer.parseInt(radek.get(3));
            Integer hodnoceni;
            boolean oblibena;
            try {
                hodnoceni = Integer.parseInt(radek.get(6));

                if (radek.get(7).equals("1")){
                    oblibena = true;
                }    else {
                    oblibena = false;
                }
            } catch (Exception e){       //když nebude moct načíst oblíbené nebo hodnocení
                oblibena = false;
                hodnoceni = 1;
            }

            Kniha nactenaKniha = new Kniha(autor, nazev, jazyk, rokVydani,pocetStran, obrazek, oblibena, hodnoceni);
            knihy.add(nactenaKniha);
        }
            return knihy;
    }
    public List<Kniha> getKnihy() {
        return knihy;
    }
}
