package cz.czechitas.citaty;

import java.util.*;
import cz.czechitas.citaty.zdroje.*;

/**
 * Trida ktera pracuje s citaty -- umi vybrat nahodny citat
 * Dalsi funkce, ktere by bylo vhodne do teto tridy umistit by byly napriklad
 * - najit citaty od konkretni autora
 * - zjistit pocet citatu
 * - zjistit pocet citatu od konkretniho autora
 */
public class CitacniSluzba {

    // "Globalni promenne tridy" nazyvane take atributy
    // Lze jse pouzivat ve vsech metodach
    private ZdrojCitatu zdroj;

    /**
     * Konstruktor tridy
     * Konstruktor je specialni "metoda", ktera se provede hned pri vytvareni objektu
     * tzn. hned kdyz zavolame <code>new CitacniSluzba(zdrojCitatu);</code>
     * Slouzi k nastaveni pocatecniho stavu objektu (Citacni sluzba potrebuje zdroj citatu)
     *
     * @param zdroj
     */
    public CitacniSluzba(ZdrojCitatu zdroj) {
        this.zdroj = zdroj;
    }

    public Citat getNahodnyCitat() {
        // zjistime kolik citatu je ve zdroji
        //int pocetCitatu = zdroj.getCitaty().size();
        int pocetCitatu = getPocetCitatu();

        // vytvorime generator nahodnych cisel
        Random generatorCisel = new Random();
        // pouzijeme generator k vygenerovani nahodneho cisla z intervalu <0, pocet citatu ve zdroji)
        int cisloCitatu = generatorCisel.nextInt(pocetCitatu);

        // vytahneme nahodny citat ze seznamu vsech citatu.
        // obdobne napriklad 3. citaty by se ziskal zdroj.getCitaty().get(2)
        // pamatuj! V Jave cislujeme od 0
        Citat nahodnyCitat = zdroj.getCitaty().get(cisloCitatu);
        return nahodnyCitat;
    }

    public int getPocetCitatu() {
        return zdroj.getCitaty().size();
    }

    public Citat getCitatOdAutora(String odAutora) {
        List<Citat> CitatOdAutora = new ArrayList<>(); //vytvoření nového prázdného listu
        // do kterého chci vložit citaty od daného autora
        Citat porovnavac;

        for (int i = 0; i < getPocetCitatu(); i++) {     //procházení citátů
            porovnavac = zdroj.getCitaty().get(i);
            if (porovnavac.getAutor().equals(odAutora)) {        //porovnání daného autora s citátem
                CitatOdAutora.add(porovnavac);         // přiřazení textu citátu do nového listu
            }
        }

        return getNahodnyCitatOdAutora(CitatOdAutora);
    }

    private Citat getNahodnyCitatOdAutora(List<Citat> citaty) {
        Random generatorCisel = new Random();
        int i = generatorCisel.nextInt(citaty.size());
        return citaty.get(i);
    }

    public int getPocetAutoru() {
        Set<String> jmena = new HashSet();
        Citat citat;
        Integer pocet;

        for (int i = 0; i < getPocetCitatu(); i++) {
            citat = zdroj.getCitaty().get(i);
            jmena.add(citat.getAutor());

        }
        pocet = jmena.size();
        return pocet;

    }

    public Citat getNahodnyOblibenyCitat() {
        List<Citat> oblibeny = new ArrayList<>();
        Citat citat;

        for (int i = 0; i < getPocetCitatu(); i++) {
            citat = zdroj.getCitaty().get(i);
            if (citat.isOblibeny()) {
                oblibeny.add(citat);
            }
        }
        if (oblibeny.size() != 0) {
            Random generatorCisel = new Random();
            int cisloNahodnehoOblibenehoCitatu = generatorCisel.nextInt(oblibeny.size());
            return oblibeny.get(cisloNahodnehoOblibenehoCitatu);
        } else {
            return null;
        }

    }
}

