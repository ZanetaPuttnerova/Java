package cz.czechitas.citaty.zdroje;

import java.io.*;
import  java.util.*;
import cz.czechitas.citaty.*;

public class SouborovyZdrojCitatu implements ZdrojCitatu {

    private List <Citat> citaty;
    private File soubor;

    public SouborovyZdrojCitatu(File soubor) {
        citaty = new ArrayList<>();
        this.soubor = soubor;
    }

    private List<Citat> nactiCitatyZeSouboru(File zdrojovySoubor) {
        List<Citat> citaty = new ArrayList<>();
        Pomocnik honzik = new Pomocnik();

        List<String> radky = honzik.nactiRadkySouboru(zdrojovySoubor);

        for (int i = 0; i< radky.size(); i = i + 3){
            String autor = radky.get(i);
            String text = radky.get(i+2);
            Citat nactenyCitat = new Citat(autor, text);
            citaty.add(nactenyCitat);   //vlozime nacteny citat do seznamu
        }
        return citaty;
    }
    public List<Citat> getCitaty()  {
        return citaty;
    }
}
