package cz.czechitas.citaty;


/**
 * Trida reprezentujici citat (citat je definovan textem a jmenem autora)
 */
public class Citat {

    // "Globalni promenne tridy" nazyvane take atributy
    // Lze jse pouzivat ve vsech metodach
    private String autor;
    private String text;
    private boolean oblibeny;

    /**
     * Konstrukotr tridy Citat.
     * Konstruktor je specialni "metoda", ktera se provede hned pri vytvareni objekt
     * tzn. hned kdyz zavolame <code>new Citat("Nekdo", "Neco chytreho");</code>
     * Slouzi k nastaveni pocatecniho stavu objektu (Citat by nedaval smysl bez textu)
     *
     * @param autor parametr "metody" pro jmeno autora
     * @param text parametr "metody" pro text citatu
     */
    public Citat(String autor, String text) {
        // this.autor se odkazuje na "globalni" promenou definovanou nahore (radek 11)
        // autor (bez this) na parametr konsturktoru (definovany na radu 23)
        this.autor = autor;
        this.text = text;
    }

    /**
     * Metoda pro pristup k atributu autor
     * Vsimni si nazvu metody
     */
    public String getAutor() {
        return autor;
    }

    public String getText() {
        return text;
    }

    public boolean isOblibeny() {
        return oblibeny;
    }

    public void setOblibeny(boolean novaHodnota) {
        oblibeny = novaHodnota;
    }
}      