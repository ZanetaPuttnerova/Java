package cz.czechitas.citaty;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
//import cz.czechitas.citaty.zdroje.*;
import cz.czechitas.citaty.zdroje.*;
import net.miginfocom.swing.*;

public class HlavniOkno extends JFrame {

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner non-commercial license
    JMenuBar menuHlavni;
    JMenu menuSoubor;
    JMenuItem menuOtevritSoubor;
    JMenuItem menuUlozitSoubor;
    JMenu menuZobrazit;
    JCheckBoxMenuItem menuPouzeOblibene;
    JMenu menu1;
    JMenuItem menuItem1;
    JMenuItem menuItem2;
    JButton btnNahodnyCitat;
    JButton btnNahodnyOdAutora;
    JButton btnNahodnyOblibeny;
    JCheckBox chckOblibeny;
    JLabel labAutor;
    JLabel labAutorEdit;
    JLabel labCitat;
    JScrollPane scrollPane1;
    JTextArea txtCitat;
    JLabel labPocetCitatuCelkemTitle;
    JLabel labPocetCitatuCelkem;
    JLabel labPocetAutoruTitle;
    JLabel labPocetAutoru;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
    // "Globalni promenne tridy" nazyvane take atributy
    // Lze jse pouzivat ve vsech metodach

    // tyto pro nas vytvorila sablona projektu
    JPanel contentPane;
    MigLayout migLayoutManager;

    // tyto jsme si definovali my
    Citat aktualniCitat;
    Citat citatOdAutora;
    ZdrojCitatu zdrojCitatu;
    CitacniSluzba citacniSluzba;


    //Mám dva problémy: tlačítko Oblíbené zůstává po použití stále zapnuté a tlačítko Citát od náhodného autora nefunguje.
    //Podívám se na to zítra, protože už usínám..

    public HlavniOkno() {
        initComponents();

        // vytvorime zdroj citatu a citacni sluzbu
        //zdrojCitatu = new StatickyZdrojCitatu();
        //citacniSluzba = new CitacniSluzba(zdrojCitatu);
        nastavCitacniSluzbu(new StatickyZdrojCitatu());

        // int pocetCitatu = citacniSluzba.getPocetCitatu(); // pouzijeme citacni sluzbu a zjistime pocet citatu
        // labPocetCitatuCelkem.setText(String.valueOf(pocetCitatu));
        pocetCitatu();
        pocetAutoru();
    }

    private void pocetCitatu() {
        int pocetCitatu = citacniSluzba.getPocetCitatu(); // pouzijeme citacni sluzbu a zjistime pocet citatu
        labPocetCitatuCelkem.setText(String.valueOf(pocetCitatu));
    }

    private void pocetAutoru(){
         int pocetAutoru = citacniSluzba.getPocetAutoru();
         labPocetAutoru.setText(String.valueOf(pocetAutoru));
    }

    /**
     * Co se ma stat pri stisknuti tlacitka "Nahodny citat"
     */
    private void stisknutoBtnNahodnyCitat(ActionEvent e) {
        aktualniCitat = citacniSluzba.getNahodnyCitat(); // pouzijeme citacni sluzbu a ziskame nahodny citat
        labAutorEdit.setText(aktualniCitat.getAutor());
        txtCitat.setText(aktualniCitat.getText());
    }

    private void stisknutoBtnNahodnyCitatOdAutora(ActionEvent e) {
        citatOdAutora = citacniSluzba.getCitatOdAutora(aktualniCitat.getAutor());
        txtCitat.setText(citatOdAutora.getText());
        chckOblibeny.setSelected(aktualniCitat.isOblibeny());

    }


    private void setMenuOtevritSoubor(ActionEvent e) {
        JFileChooser vyberovyDialog = new JFileChooser();
        int vysledek = vyberovyDialog.showOpenDialog(this);
        if (vysledek == JFileChooser.APPROVE_OPTION) {
            File soubor = vyberovyDialog.getSelectedFile();
            nastavCitacniSluzbu(new SouborovyZdrojCitatu(soubor));
            pocetAutoru();
            pocetCitatu();
        }
        }

    private void nastavCitacniSluzbu(ZdrojCitatu zdroj) {
        zdrojCitatu = zdroj;
        citacniSluzba = new CitacniSluzba(zdroj);
    }

    private void chckOblibenyKlik(ActionEvent e) {
        aktualniCitat.setOblibeny(chckOblibeny.isSelected());
    }

    private void btnNahodnyOblibenyCitatKlik(ActionEvent e) {
        aktualniCitat = citacniSluzba.getNahodnyOblibenyCitat();
        labAutorEdit.setText(aktualniCitat.getAutor());
        txtCitat.setText(aktualniCitat.getText());
        chckOblibeny.setSelected(aktualniCitat.isOblibeny());
    }



    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner non-commercial license
        menuHlavni = new JMenuBar();
        menuSoubor = new JMenu();
        menuOtevritSoubor = new JMenuItem();
        menuUlozitSoubor = new JMenuItem();
        menuZobrazit = new JMenu();
        menuPouzeOblibene = new JCheckBoxMenuItem();
        menu1 = new JMenu();
        menuItem1 = new JMenuItem();
        menuItem2 = new JMenuItem();
        btnNahodnyCitat = new JButton();
        btnNahodnyOdAutora = new JButton();
        btnNahodnyOblibeny = new JButton();
        chckOblibeny = new JCheckBox();
        labAutor = new JLabel();
        labAutorEdit = new JLabel();
        labCitat = new JLabel();
        scrollPane1 = new JScrollPane();
        txtCitat = new JTextArea();
        labPocetCitatuCelkemTitle = new JLabel();
        labPocetCitatuCelkem = new JLabel();
        labPocetAutoruTitle = new JLabel();
        labPocetAutoru = new JLabel();

        //======== this ========
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Prohl\u00ed\u017ee\u010d cit\u00e1t\u016f");
        Container contentPane = getContentPane();
        contentPane.setLayout(new MigLayout(
            "insets rel,hidemode 3",
            // columns
            "[fill]" +
            "[left]" +
            "[fill]" +
            "[fill]" +
            "[fill]" +
            "[grow,fill]",
            // rows
            "[fill]" +
            "[]" +
            "[]" +
            "[grow]" +
            "[]" +
            "[]"));
        this.contentPane = (JPanel) this.getContentPane();
        this.contentPane.setBackground(this.getBackground());
        LayoutManager layout = this.contentPane.getLayout();
        if (layout instanceof MigLayout) {
            this.migLayoutManager = (MigLayout) layout;
        }

        //======== menuHlavni ========
        {

            //======== menuSoubor ========
            {
                menuSoubor.setText("Soubor");

                //---- menuOtevritSoubor ----
                menuOtevritSoubor.setText("Otev\u0159\u00edt");
                menuOtevritSoubor.addActionListener(e -> setMenuOtevritSoubor(e));
                menuSoubor.add(menuOtevritSoubor);

                //---- menuUlozitSoubor ----
                menuUlozitSoubor.setText("Ulo\u017eit");
                menuSoubor.add(menuUlozitSoubor);
            }
            menuHlavni.add(menuSoubor);

            //======== menuZobrazit ========
            {
                menuZobrazit.setText("Zobrazit");

                //---- menuPouzeOblibene ----
                menuPouzeOblibene.setText("Pouze Obl\u00edben\u00e9");
                menuZobrazit.add(menuPouzeOblibene);
            }
            menuHlavni.add(menuZobrazit);

            //======== menu1 ========
            {
                menu1.setText("Nastroje");

                //---- menuItem1 ----
                menuItem1.setText("neco");
                menu1.add(menuItem1);

                //---- menuItem2 ----
                menuItem2.setText("neco dalsi");
                menu1.add(menuItem2);
            }
            menuHlavni.add(menu1);
        }
        setJMenuBar(menuHlavni);

        //---- btnNahodnyCitat ----
        btnNahodnyCitat.setText("N\u00e1hodn\u00fd cit\u00e1t");
        btnNahodnyCitat.addActionListener(e -> stisknutoBtnNahodnyCitat(e));
        contentPane.add(btnNahodnyCitat, "cell 0 0 2 1");

        //---- btnNahodnyOdAutora ----
        btnNahodnyOdAutora.setText("N\u00e1hodn\u00fd od autora");
        contentPane.add(btnNahodnyOdAutora, "cell 2 0 2 1");

        //---- btnNahodnyOblibeny ----
        btnNahodnyOblibeny.setText("N\u00e1hodn\u00fd obl\u00edben\u00fd cit\u00e1t");
        btnNahodnyOblibeny.addActionListener(e -> btnNahodnyOblibenyCitatKlik(e));
        contentPane.add(btnNahodnyOblibeny, "cell 4 0");

        //---- chckOblibeny ----
        chckOblibeny.setText("Obl\u00edben\u00fd");
        chckOblibeny.addActionListener(e -> chckOblibenyKlik(e));
        contentPane.add(chckOblibeny, "cell 4 0");

        //---- labAutor ----
        labAutor.setText("Autor");
        contentPane.add(labAutor, "cell 0 1,alignx center,growx 0");
        contentPane.add(labAutorEdit, "cell 1 1 4 1,alignx left,growx 0");

        //---- labCitat ----
        labCitat.setText("Citat");
        contentPane.add(labCitat, "cell 0 2,alignx center,growx 0");

        //======== scrollPane1 ========
        {

            //---- txtCitat ----
            txtCitat.setLineWrap(true);
            txtCitat.setColumns(60);
            txtCitat.setRows(20);
            txtCitat.setEditable(false);
            scrollPane1.setViewportView(txtCitat);
        }
        contentPane.add(scrollPane1, "cell 1 2 5 2,grow");

        //---- labPocetCitatuCelkemTitle ----
        labPocetCitatuCelkemTitle.setText("Cit\u00e1t\u016f celkem:");
        contentPane.add(labPocetCitatuCelkemTitle, "cell 0 5");

        //---- labPocetCitatuCelkem ----
        labPocetCitatuCelkem.setText("0");
        contentPane.add(labPocetCitatuCelkem, "cell 1 5,alignx left,growx 0");

        //---- labPocetAutoruTitle ----
        labPocetAutoruTitle.setText("| Celkem Autor\u016f:");
        contentPane.add(labPocetAutoruTitle, "cell 2 5");

        //---- labPocetAutoru ----
        labPocetAutoru.setText("0");
        contentPane.add(labPocetAutoru, "cell 3 5");
        pack();
        setLocationRelativeTo(null);
        // JFormDesigner - End of component initialization  //GEN-END:initComponents

    }
}
