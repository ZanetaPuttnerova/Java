package cz.czechitas.knihy;

import java.io.*;
import java.util.*;
import cz.czechitas.knihy.ZdrojDat.*;

public class KnihovniSluzba {

    private ZdrojDat zdrojDat;

    public Kniha getKniha(int i) {
        return zdrojDat.getKniha(i);
    }

    public KnihovniSluzba(ZdrojDat zdrojDat) {
        this.zdrojDat = zdrojDat;
    }

    public Kniha getNahodnaKniha() {
        int pocetKnih = getPocetKnih();
        Random generatorKnih = new Random();
        int cisloKnihy = generatorKnih.nextInt(pocetKnih);
        Kniha nahodnaKniha = zdrojDat.getKnihy().get(cisloKnihy);
        return nahodnaKniha;
    }

    public int getPocetKnih() {
        return zdrojDat.getKnihy().size();
    }

    public Kniha getKnihyOdAutora(String odAutora) {
        List<Kniha> knihaOdAutora = new ArrayList<>();
        Kniha porovnavac;

        for (int i = 0; i < getPocetKnih(); i++) {
            porovnavac = zdrojDat.getKnihy().get(i);
            if (porovnavac.getAutor().equals(odAutora)) {
                knihaOdAutora.add(porovnavac);
            }
        }
        return getNahodnaKnihaOdAutora(knihaOdAutora);
    }

    private Kniha getNahodnaKnihaOdAutora(List<Kniha> knihy) {
        Random generatorCisel = new Random();
        int i = generatorCisel.nextInt(knihy.size());
        return knihy.get(i);
    }

    public Kniha getNahodnaOblibenaKniha() {
        List<Kniha> oblibena = new ArrayList<>();
        Kniha kniha;

        for (int i = 0; i < getPocetKnih(); i++) {
            kniha = zdrojDat.getKnihy().get(i);
            if (kniha.isOblibeny()) {
                oblibena.add(kniha);
            }
        }
        if (oblibena.size() != 0) {
            Random generatorCisel = new Random();
            int cisloNahodneOblibeneKnihy = generatorCisel.nextInt(oblibena.size());
            return oblibena.get(cisloNahodneOblibeneKnihy);
        } else {
            return null;
        }
    }

    public void ulozKnihyDoSouboru(File soubor) {
        Pomocnik karel = new Pomocnik();
        List<String> radky = new ArrayList<>();      //vytvoříme nový prázdný seznam řádků k zápisu
        for (int i = 0; i < getPocetKnih(); i++) {    // postupně procházíme všechny citáty
            Kniha kniha = zdrojDat.getKnihy().get(i);     //z každého citátu bereme autora.., a přidáváme do seznamu řádků, které chceme později vypsat
            String autor = kniha.getAutor();

            String oblibeny;
            if (kniha.isOblibeny()) {
                oblibeny = "1";       // bez String jinak bychom nastavili novou proměnnou
            } else {
                oblibeny = "0";
            }

            //String oblibeny = citat.isOblibeny();
            String nazev = kniha.getNazev();
            String jazyk = kniha.getJazyk();
            Integer pocetStran = kniha.getPocetStran();
            int rokVydani = kniha.getRokVydani();
            int hodnoceni = kniha.getHodnoceni();
            // to vše String for (kniha.setHodnoceni();)
            String obrazek = kniha.getObrazek();
            //nejdřív řádky přidám
            radky.add(autor);
            radky.add(nazev);
            radky.add(jazyk);
            radky.add(String.valueOf(pocetStran));
            radky.add(String.valueOf(rokVydani));
            radky.add(String.valueOf(hodnoceni));
            radky.add(oblibeny);
            radky.add(obrazek);

            karel.zapisRadkyDoSouboru(radky, soubor);
        }

    }

    public Kniha najdi(String nazev) {
        for (int i = 0; i < getPocetKnih(); i++) {
            Kniha kniha = zdrojDat.getKnihy().get(i);
            if (kniha.getNazev().indexOf(nazev) == 0) { //vyhledava nazev: index, kde zacina text
                return kniha;
            }
        }
        return new Kniha("nenalezeno", "nenalezeno", "nenalezeno", 0, 0, "", false, 5);
    }
}


        /*if (oblibeneKnihy) {
            int pocetOblibenychKnih = getPocetOblibenychKnih();
            Random generatorCisel = new Random();
            int cisloKnihy = generatorCisel.nextInt(pocetOblibenychKnih);
            Kniha nahodnaOblibenaKniha = getOblibena(cisloKnihy);
            return nahodnaOblibenaKniha;
        } else {
            int pocetKnih = getPocetKnih();
            Random generatorCisel = new Random();
            int cisloKnihy = generatorCisel.nextInt(pocetKnih);

            Kniha nahodnaOblibenaKniha = zdrojDat.getKnihy().get(cisloKnihy);
            return nahodnaOblibenaKniha;
        }

    }

    public int getPocetOblibenychKnih(){
         List<Kniha> seznam = zdrojDat.getKnihy();
         int pocet = 0;
         for (Kniha kniha: seznam) {
            if (kniha.isOblibeny()){
                pocet++;
            }
         }
         return pocet;
    }

    public Kniha getOblibena(int i){
        List<Kniha> seznam = zdrojDat.getKnihy();
        int pocet = 0;
        for (Kniha kniha: seznam) {

            if (kniha.isOblibeny()){
               if (i == pocet){
                   return kniha;
               }    else {
                   pocet++;
               }

            }
        }
        return null;
    }
*/