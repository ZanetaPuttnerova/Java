package cz.czechitas.knihy;

import javax.swing.*;
import com.sun.xml.internal.ws.api.ha.*;

public class Kniha {

    private String autor;
    private String nazev;
    private String jazyk;
    private Integer rokVydani;
    private Integer pocetStran;
    private boolean oblibeny;
    private String obrazek;
    private Integer hodnoceni;
    //private int hodnoceni;
    //private ImageIcon icon;

    public Kniha(String autor, String nazev, String jazyk, Integer rokVydani, Integer pocetStran, String obrazek, boolean oblibena, Integer hodnoceni){
        this.autor = autor;
        this.nazev = nazev;
        this.jazyk = jazyk;
        this.rokVydani = rokVydani;
        this.pocetStran = pocetStran;
        this.obrazek = obrazek;
        this.oblibeny = oblibena; //druhý je ten v závorce
        this.hodnoceni = hodnoceni;
    }

    //public Kniha(String autor, String nazev, String jazyk, int rokVydani, int pocetStran, String obrazek) {
    //}

    public String getAutor() {
        return autor;
    }

    public String getNazev() {
        throw new UnsupportedOperationException();
    }

    public String getJazyk() {
        return jazyk;
    }

    public Integer getPocetStran() {
        return pocetStran;
    }

    public Integer getRokVydani() {
        return rokVydani;
    }

    public boolean isOblibeny(){
        return oblibeny;
    }

    public void setOblibeny(boolean novaHodnota) {
        oblibeny = novaHodnota;
    }

    public String getObrazek(){
        return obrazek;
    }

    public void setHodnoceni(Integer value) {
        this.hodnoceni = hodnoceni;
    }

    public int getHodnoceni(){
        return hodnoceni;
    }

    public void setHodnoceni(int stupen){
        hodnoceni = stupen;
    }

    //public ImageIcon getIcon(){
    //}


}
