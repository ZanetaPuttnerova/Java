package cz.czechitas.citaty.zdroje;

import java.util.*;
import cz.czechitas.citaty.*;

public interface ZdrojCitatu {
    public List<Citat> getCitaty();
}
